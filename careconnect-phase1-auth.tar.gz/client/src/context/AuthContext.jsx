import React, {
    createContext,
    useState,
    useEffect,
    useContext,
    useCallback,
    useRef,
} from 'react';
import {
    login    as loginApi,
    logout   as logoutApi,
    logoutAll as logoutAllApi,
    refreshToken,
    getMe,
} from '../api/auth.js';
import { setAccessToken, clearAccessToken } from '../api/index.js';

// ─── Context ──────────────────────────────────────────────────────────────────

const AuthContext = createContext(null);

// ─── Provider ─────────────────────────────────────────────────────────────────

export const AuthProvider = ({ children }) => {
    const [user,    setUser]    = useState(null);
    const [loading, setLoading] = useState(true); // true while we attempt silent refresh on mount

    // Prevent double-calling the refresh on StrictMode double-mount
    const refreshAttempted = useRef(false);

    // ── Silent refresh on app load ────────────────────────────────────────────
    // The httpOnly cookie is sent automatically. If it is valid, the server
    // returns a new access token and we restore the session without a login page.
    useEffect(() => {
        if (refreshAttempted.current) return;
        refreshAttempted.current = true;

        const restoreSession = async () => {
            try {
                const { data: tokenData } = await refreshToken();
                setAccessToken(tokenData.accessToken);

                const { data: meData } = await getMe();
                setUser(meData.user);
            } catch {
                // No valid session — user needs to log in
                clearAccessToken();
                setUser(null);
            } finally {
                setLoading(false);
            }
        };

        restoreSession();
    }, []);

    // ── Listen for session-expired event (fired by Axios interceptor) ─────────
    useEffect(() => {
        const handleExpired = () => {
            clearAccessToken();
            setUser(null);
        };
        window.addEventListener('auth:session-expired', handleExpired);
        return () => window.removeEventListener('auth:session-expired', handleExpired);
    }, []);

    // ── login ─────────────────────────────────────────────────────────────────
    const login = useCallback(async (email, password) => {
        const { data } = await loginApi({ email, password });
        setAccessToken(data.accessToken);
        setUser(data.user);
        return data.user;
    }, []);

    // ── logout ────────────────────────────────────────────────────────────────
    const logout = useCallback(async () => {
        try {
            await logoutApi(); // revokes refresh token on server
        } catch {
            // Best-effort — always clear locally
        } finally {
            clearAccessToken();
            setUser(null);
        }
    }, []);

    // ── logout from all devices ───────────────────────────────────────────────
    const logoutAll = useCallback(async () => {
        try {
            await logoutAllApi();
        } catch {
            // Best-effort
        } finally {
            clearAccessToken();
            setUser(null);
        }
    }, []);

    // ── update user in context (e.g. after profile edit) ─────────────────────
    const updateUser = useCallback((updates) => {
        setUser((prev) => prev ? { ...prev, ...updates } : prev);
    }, []);

    const value = {
        user,
        loading,
        isAuthenticated: !!user,
        login,
        logout,
        logoutAll,
        updateUser,
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};

// ─── Hook ─────────────────────────────────────────────────────────────────────

export const useAuth = () => {
    const ctx = useContext(AuthContext);
    if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
    return ctx;
};
