import axios from 'axios';

// ─── Access token store ───────────────────────────────────────────────────────
// The access token is held in module memory — never localStorage, never a cookie.
// It is lost on page refresh, which is intentional: /api/auth/refresh restores it
// using the httpOnly refresh cookie the browser sends automatically.

let _accessToken = null;

export const setAccessToken  = (token) => { _accessToken = token; };
export const getAccessToken  = ()      => _accessToken;
export const clearAccessToken = ()     => { _accessToken = null; };

// ─── Axios instance ───────────────────────────────────────────────────────────

const API = axios.create({
    baseURL:         import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
    withCredentials: true,   // send the httpOnly refresh cookie on every request
    timeout:         15000,  // 15 s timeout
});

// ─── Request interceptor — attach access token ────────────────────────────────

API.interceptors.request.use(
    (config) => {
        const token = getAccessToken();
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

// ─── Response interceptor — silent token refresh on 401 ──────────────────────
// When the access token expires (15 min), the server returns 401.
// This interceptor calls /auth/refresh once, updates the in-memory token,
// and retries the original request — the user sees nothing.

let isRefreshing   = false;
let refreshQueue   = []; // queued requests waiting for the new token

const processQueue = (error, token = null) => {
    refreshQueue.forEach(({ resolve, reject }) => {
        if (error) reject(error);
        else resolve(token);
    });
    refreshQueue = [];
};

API.interceptors.response.use(
    (response) => response,
    async (error) => {
        const originalRequest = error.config;

        // Only attempt refresh on 401, not on the refresh endpoint itself
        // and not if we already retried this request.
        if (
            error.response?.status === 401 &&
            !originalRequest._retry &&
            !originalRequest.url.includes('/auth/refresh') &&
            !originalRequest.url.includes('/auth/login')
        ) {
            if (isRefreshing) {
                // Another request is already refreshing — queue this one
                return new Promise((resolve, reject) => {
                    refreshQueue.push({ resolve, reject });
                }).then((token) => {
                    originalRequest.headers.Authorization = `Bearer ${token}`;
                    return API(originalRequest);
                });
            }

            originalRequest._retry = true;
            isRefreshing            = true;

            try {
                const { data } = await API.post('/auth/refresh');
                const newToken  = data.accessToken;

                setAccessToken(newToken);
                processQueue(null, newToken);

                originalRequest.headers.Authorization = `Bearer ${newToken}`;
                return API(originalRequest);
            } catch (refreshError) {
                processQueue(refreshError, null);
                clearAccessToken();
                // Dispatch a custom event so AuthContext can react (redirect to login)
                window.dispatchEvent(new CustomEvent('auth:session-expired'));
                return Promise.reject(refreshError);
            } finally {
                isRefreshing = false;
            }
        }

        return Promise.reject(error);
    }
);

export default API;
