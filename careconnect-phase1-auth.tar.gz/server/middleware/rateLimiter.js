import rateLimit from 'express-rate-limit';
import getRedisClient from '../config/redis.js';

// ─── Redis store for rate limiter ─────────────────────────────────────────────
// Uses ioredis directly — no extra package needed.
// Keys: rl:{routeKey}:{ip}  →  count (auto-expiring)

const makeRedisStore = (prefix) => ({
    init: () => {},
    async increment(key) {
        const redis    = getRedisClient();
        const redisKey = `rl:${prefix}:${key}`;
        const current  = await redis.incr(redisKey);

        // Set expiry on first increment only
        if (current === 1) {
            await redis.expire(redisKey, 900); // 15 min window
        }

        return { totalHits: current, resetTime: undefined };
    },
    async decrement(key) {
        const redis    = getRedisClient();
        const redisKey = `rl:${prefix}:${key}`;
        await redis.decr(redisKey);
    },
    async resetKey(key) {
        const redis    = getRedisClient();
        const redisKey = `rl:${prefix}:${key}`;
        await redis.del(redisKey);
    },
});

// ─── Login rate limiter ───────────────────────────────────────────────────────
// 5 attempts per 15 minutes per IP.
// This works alongside the per-account lockout in the User model.
// Two layers: IP-level (this) + account-level (User.recordFailedLogin).

export const loginRateLimiter = rateLimit({
    windowMs:         15 * 60 * 1000, // 15 minutes
    max:              5,
    message: {
        message: 'Too many login attempts from this IP. Please try again in 15 minutes.',
    },
    standardHeaders:  true,  // Return rate limit info in RateLimit-* headers
    legacyHeaders:    false,
    skipSuccessfulRequests: true, // Only count failed attempts
    store: makeRedisStore('login'),
    keyGenerator: (req) =>
        // Key by IP + email combo to prevent distributed attacks targeting one account
        `${req.ip}:${(req.body?.email || '').toLowerCase()}`,
});

// ─── Register rate limiter ────────────────────────────────────────────────────
// 3 registrations per hour per IP — prevents account farming.

export const registerRateLimiter = rateLimit({
    windowMs:        60 * 60 * 1000, // 1 hour
    max:             3,
    message: {
        message: 'Too many accounts created from this IP. Please try again later.',
    },
    standardHeaders: true,
    legacyHeaders:   false,
    store:           makeRedisStore('register'),
});

// ─── Refresh token rate limiter ───────────────────────────────────────────────
// 30 refreshes per 15 minutes per IP — allows normal SPA token rotation
// but blocks automated refresh-token hammering.

export const refreshRateLimiter = rateLimit({
    windowMs:        15 * 60 * 1000,
    max:             30,
    message: {
        message: 'Too many token refresh requests. Please try again later.',
    },
    standardHeaders: true,
    legacyHeaders:   false,
    store:           makeRedisStore('refresh'),
});

// ─── General API rate limiter ─────────────────────────────────────────────────
// Applied globally to all /api/* routes as a baseline.
// 200 requests per 15 minutes per IP.

export const apiRateLimiter = rateLimit({
    windowMs:        15 * 60 * 1000,
    max:             200,
    message: {
        message: 'Too many requests from this IP. Please slow down.',
    },
    standardHeaders: true,
    legacyHeaders:   false,
    store:           makeRedisStore('api'),
});
