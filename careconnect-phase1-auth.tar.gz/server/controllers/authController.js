import User from '../models/User.js';
import {
    generateAccessToken,
    generateRefreshToken,
    verifyRefreshToken,
    revokeRefreshToken,
    revokeAllRefreshTokens,
    setRefreshCookie,
    clearRefreshCookie,
    getRefreshCookie,
} from '../utils/tokens.js';
import audit from '../utils/audit.js';

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Build the safe user payload returned to the client.
 * Never includes password, loginAttempts, lockUntil, mfaSecret.
 */
const safeUser = (user) => ({
    _id:   user._id,
    name:  user.name,
    email: user.email,
    role:  user.role,
    mfaEnabled: user.mfaEnabled,
});

// ─── @desc    Register a new patient (public self-service) ────────────────────
// @route   POST /api/auth/register
// @access  Public
const registerUser = async (req, res) => {
    try {
        const { name, email, password } = req.body;
        // req.body is already validated and sanitised by Zod middleware

        const userExists = await User.findOne({ email, deletedAt: null });
        if (userExists) {
            return res.status(409).json({ message: 'An account with this email already exists' });
        }

        // Role is always 'patient' on the public register route — never trust the body
        const user = await User.create({ name, email, password, role: 'patient' });

        const accessToken  = generateAccessToken(user);
        const refreshToken = await generateRefreshToken(user._id);

        setRefreshCookie(res, refreshToken);

        audit(req, 'AUTH_LOGIN_SUCCESS', {
            actorId:   user._id,
            actorRole: user.role,
            meta:      { event: 'registration' },
        });

        return res.status(201).json({
            user:        safeUser(user),
            accessToken, // short-lived, held in memory by the client
        });
    } catch (err) {
        console.error('[Auth] registerUser error:', err.message);
        return res.status(500).json({ message: 'Registration failed. Please try again.' });
    }
};

// ─── @desc    Login ───────────────────────────────────────────────────────────
// @route   POST /api/auth/login
// @access  Public
const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Fetch user with sensitive fields explicitly selected
        const user = await User
            .findOne({ email, deletedAt: null })
            .select('+password +loginAttempts +lockUntil +passwordChangedAt');

        // ── Account does not exist ────────────────────────────────────────────
        if (!user) {
            // Do NOT reveal whether the email exists — return identical response
            audit(req, 'AUTH_LOGIN_FAILED', {
                success: false,
                meta:    { reason: 'user_not_found', email },
            });
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        // ── Account is locked ─────────────────────────────────────────────────
        if (user.isLocked) {
            const minutesLeft = Math.ceil((user.lockUntil - Date.now()) / 60000);
            audit(req, 'AUTH_LOGIN_FAILED', {
                actorId:  user._id,
                actorRole: user.role,
                success:  false,
                meta:     { reason: 'account_locked' },
            });
            return res.status(423).json({
                message: `Account locked due to too many failed attempts. Try again in ${minutesLeft} minute${minutesLeft === 1 ? '' : 's'}.`,
            });
        }

        // ── Wrong password ────────────────────────────────────────────────────
        const isMatch = await user.matchPassword(password);
        if (!isMatch) {
            await user.recordFailedLogin();

            // Warn user if they are close to lockout
            const attemptsAfter = user.loginAttempts + 1;
            const remaining     = 5 - attemptsAfter;

            audit(req, 'AUTH_LOGIN_FAILED', {
                actorId:   user._id,
                actorRole: user.role,
                success:   false,
                meta:      { reason: 'wrong_password', attemptsAfter },
            });

            if (attemptsAfter >= 5) {
                audit(req, 'AUTH_ACCOUNT_LOCKED', {
                    actorId:   user._id,
                    actorRole: user.role,
                });
                return res.status(423).json({
                    message: 'Account locked due to too many failed attempts. Try again in 15 minutes.',
                });
            }

            return res.status(401).json({
                message: `Invalid email or password. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining before lockout.`,
            });
        }

        // ── Successful login ──────────────────────────────────────────────────
        await user.resetLoginAttempts();

        const accessToken  = generateAccessToken(user);
        const refreshToken = await generateRefreshToken(user._id);

        setRefreshCookie(res, refreshToken);

        audit(req, 'AUTH_LOGIN_SUCCESS', {
            actorId:   user._id,
            actorRole: user.role,
        });

        return res.status(200).json({
            user:        safeUser(user),
            accessToken,
        });
    } catch (err) {
        console.error('[Auth] loginUser error:', err.message);
        return res.status(500).json({ message: 'Login failed. Please try again.' });
    }
};

// ─── @desc    Refresh access token ───────────────────────────────────────────
// @route   POST /api/auth/refresh
// @access  Public (requires valid refresh cookie)
const refreshAccessToken = async (req, res) => {
    try {
        const token = getRefreshCookie(req);

        if (!token) {
            return res.status(401).json({ message: 'No refresh token provided' });
        }

        // Verify signature + Redis existence in one call
        const payload = await verifyRefreshToken(token);

        const user = await User
            .findById(payload.id)
            .select('+passwordChangedAt');

        if (!user || user.deletedAt) {
            return res.status(401).json({ message: 'User not found' });
        }

        // If password changed after this token was issued, invalidate everything
        if (user.isTokenIssuedBeforePasswordChange(payload.iat)) {
            await revokeAllRefreshTokens(user._id);
            clearRefreshCookie(res);
            return res.status(401).json({
                message: 'Password recently changed. Please log in again.',
            });
        }

        // Rotate: revoke old refresh token, issue new pair
        await revokeRefreshToken(token);
        const newAccessToken  = generateAccessToken(user);
        const newRefreshToken = await generateRefreshToken(user._id);

        setRefreshCookie(res, newRefreshToken);

        audit(req, 'AUTH_TOKEN_REFRESHED', {
            actorId:   user._id,
            actorRole: user.role,
        });

        return res.status(200).json({ accessToken: newAccessToken });
    } catch (err) {
        // verifyRefreshToken throws if token is invalid/revoked
        clearRefreshCookie(res);
        return res.status(401).json({ message: 'Invalid or expired session. Please log in again.' });
    }
};

// ─── @desc    Logout ──────────────────────────────────────────────────────────
// @route   POST /api/auth/logout
// @access  Private (requires valid access token)
const logoutUser = async (req, res) => {
    try {
        const token = getRefreshCookie(req);

        if (token) {
            // Revoke the specific refresh token from Redis
            await revokeRefreshToken(token);
        }

        clearRefreshCookie(res);

        audit(req, 'AUTH_LOGOUT', {
            actorId:   req.user?._id ?? null,
            actorRole: req.user?.role ?? 'anonymous',
        });

        return res.status(200).json({ message: 'Logged out successfully' });
    } catch (err) {
        console.error('[Auth] logoutUser error:', err.message);
        // Still clear the cookie even if Redis call fails
        clearRefreshCookie(res);
        return res.status(200).json({ message: 'Logged out' });
    }
};

// ─── @desc    Logout from all devices ────────────────────────────────────────
// @route   POST /api/auth/logout-all
// @access  Private
const logoutAllDevices = async (req, res) => {
    try {
        await revokeAllRefreshTokens(req.user._id);
        clearRefreshCookie(res);

        audit(req, 'AUTH_LOGOUT', {
            actorId:   req.user._id,
            actorRole: req.user.role,
            meta:      { allDevices: true },
        });

        return res.status(200).json({ message: 'Logged out from all devices' });
    } catch (err) {
        console.error('[Auth] logoutAllDevices error:', err.message);
        return res.status(500).json({ message: 'Failed to logout from all devices' });
    }
};

// ─── @desc    Change password ─────────────────────────────────────────────────
// @route   PUT /api/auth/change-password
// @access  Private
const changePassword = async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;

        const user = await User
            .findById(req.user._id)
            .select('+password');

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const isMatch = await user.matchPassword(currentPassword);
        if (!isMatch) {
            return res.status(401).json({ message: 'Current password is incorrect' });
        }

        user.password = newPassword;
        await user.save(); // pre-save hook hashes + sets passwordChangedAt

        // Revoke ALL existing refresh tokens — force re-login on all devices
        await revokeAllRefreshTokens(user._id);
        clearRefreshCookie(res);

        audit(req, 'AUTH_PASSWORD_CHANGED', {
            actorId:   user._id,
            actorRole: user.role,
        });

        return res.status(200).json({
            message: 'Password changed successfully. Please log in again.',
        });
    } catch (err) {
        console.error('[Auth] changePassword error:', err.message);
        return res.status(500).json({ message: 'Failed to change password. Please try again.' });
    }
};

// ─── @desc    Get current user (validate session) ────────────────────────────
// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res) => {
    try {
        const user = await User.findById(req.user._id);
        if (!user || user.deletedAt) {
            return res.status(404).json({ message: 'User not found' });
        }
        return res.status(200).json({ user: safeUser(user) });
    } catch (err) {
        return res.status(500).json({ message: 'Failed to fetch user' });
    }
};

export {
    registerUser,
    loginUser,
    refreshAccessToken,
    logoutUser,
    logoutAllDevices,
    changePassword,
    getMe,
};
