import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = mongoose.Schema(
    {
        name: {
            type:     String,
            required: [true, 'Name is required'],
            trim:     true,
            maxlength: [100, 'Name cannot exceed 100 characters'],
        },
        email: {
            type:      String,
            required:  [true, 'Email is required'],
            unique:    true,
            lowercase: true,
            trim:      true,
        },
        password: {
            type:     String,
            required: [true, 'Password is required'],
            select:   false, // never returned in queries unless explicitly requested
        },
        role: {
            type:    String,
            required: true,
            enum:    ['patient', 'doctor', 'receptionist', 'admin'],
            default: 'patient',
        },

        // ── Account lockout ──────────────────────────────────────────────────
        loginAttempts: {
            type:    Number,
            default: 0,
            select:  false,
        },
        lockUntil: {
            type:   Date,
            select: false,
        },

        // ── Password rotation tracking ───────────────────────────────────────
        // Used to invalidate refresh tokens issued before a password change.
        passwordChangedAt: {
            type:   Date,
            select: false,
        },

        // ── Soft delete ──────────────────────────────────────────────────────
        deletedAt: {
            type:    Date,
            default: null,
        },

        // ── Future: MFA (Phase 2 — fields present but not enforced yet) ──────
        mfaEnabled: {
            type:    Boolean,
            default: false,
        },
        mfaSecret: {
            type:   String,
            select: false,
        },
    },
    { timestamps: true }
);

// ─── Constants ────────────────────────────────────────────────────────────────
const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_DURATION_MS   = 15 * 60 * 1000; // 15 minutes

// ─── Virtual: is the account currently locked? ───────────────────────────────
userSchema.virtual('isLocked').get(function () {
    return !!(this.lockUntil && this.lockUntil > Date.now());
});

// ─── Pre-save: hash password + record passwordChangedAt ──────────────────────
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();

    const salt    = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);

    // Record when the password changed so we can invalidate old refresh tokens.
    // Skip on initial creation (passwordChangedAt would equal createdAt).
    if (!this.isNew) {
        this.passwordChangedAt = new Date(Date.now() - 1000); // 1 s in the past
    }

    next();
});

// ─── Instance method: compare password ───────────────────────────────────────
userSchema.methods.matchPassword = async function (enteredPassword) {
    return bcrypt.compare(enteredPassword, this.password);
};

// ─── Instance method: record a failed login attempt ──────────────────────────
userSchema.methods.recordFailedLogin = async function () {
    // If a previous lock has expired, reset the counter
    if (this.lockUntil && this.lockUntil < Date.now()) {
        return this.updateOne({
            $set: { loginAttempts: 1 },
            $unset: { lockUntil: 1 },
        });
    }

    const update = { $inc: { loginAttempts: 1 } };

    if (this.loginAttempts + 1 >= MAX_LOGIN_ATTEMPTS) {
        update.$set = { lockUntil: new Date(Date.now() + LOCK_DURATION_MS) };
    }

    return this.updateOne(update);
};

// ─── Instance method: reset login attempts after successful login ─────────────
userSchema.methods.resetLoginAttempts = async function () {
    return this.updateOne({
        $set:   { loginAttempts: 0 },
        $unset: { lockUntil: 1 },
    });
};

// ─── Instance method: was this token issued before a password change? ─────────
userSchema.methods.isTokenIssuedBeforePasswordChange = function (tokenIssuedAt) {
    if (!this.passwordChangedAt) return false;
    // tokenIssuedAt is in seconds (JWT iat), passwordChangedAt is a Date
    return this.passwordChangedAt.getTime() / 1000 > tokenIssuedAt;
};

// ─── Index ────────────────────────────────────────────────────────────────────
userSchema.index({ email: 1 });
userSchema.index({ deletedAt: 1 });

const User = mongoose.model('User', userSchema);
export default User;
