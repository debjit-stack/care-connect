import mongoose from 'mongoose';

const auditLogSchema = mongoose.Schema(
    {
        // Who did the action
        actorId: {
            type: mongoose.Schema.Types.ObjectId,
            ref:  'User',
            default: null, // null for unauthenticated events (failed logins)
        },
        actorRole: {
            type: String,
            enum: ['patient', 'doctor', 'receptionist', 'admin', 'system', 'anonymous'],
            default: 'anonymous',
        },

        // What happened
        action: {
            type:     String,
            required: true,
            enum: [
                // Auth events
                'AUTH_LOGIN_SUCCESS',
                'AUTH_LOGIN_FAILED',
                'AUTH_LOGOUT',
                'AUTH_TOKEN_REFRESHED',
                'AUTH_PASSWORD_CHANGED',
                'AUTH_ACCOUNT_LOCKED',
                // Data events (Phase 2+)
                'DATA_READ',
                'DATA_CREATE',
                'DATA_UPDATE',
                'DATA_DELETE',
            ],
        },

        // What was acted upon
        resourceType: {
            type:    String,
            default: null, // e.g. 'Appointment', 'User', 'HealthPackage'
        },
        resourceId: {
            type:    String,
            default: null,
        },

        // Request context
        ipAddress: {
            type:    String,
            default: null,
        },
        userAgent: {
            type:    String,
            default: null,
        },

        // Outcome
        success: {
            type:    Boolean,
            default: true,
        },
        meta: {
            type:    mongoose.Schema.Types.Mixed,
            default: {},
            // Store additional context: error message on failure, changed fields, etc.
        },
    },
    {
        timestamps: true,
        // Audit logs are append-only — disable update/delete operations at schema level
        // (enforced in application logic — never call AuditLog.updateOne/deleteOne)
    }
);

// ─── Indexes ──────────────────────────────────────────────────────────────────
auditLogSchema.index({ actorId: 1, createdAt: -1 });
auditLogSchema.index({ action: 1,  createdAt: -1 });
auditLogSchema.index({ resourceType: 1, resourceId: 1 });
// TTL index: auto-delete logs older than 7 years (healthcare retention requirement)
auditLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 7 * 365 * 24 * 60 * 60 });

const AuditLog = mongoose.model('AuditLog', auditLogSchema);
export default AuditLog;
