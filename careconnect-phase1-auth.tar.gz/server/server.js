import express    from 'express';
import dotenv     from 'dotenv';
import cors       from 'cors';
import helmet     from 'helmet';
import cookieParser from 'cookie-parser';
import connectDB  from './config/db.js';
import getRedisClient from './config/redis.js';
import { apiRateLimiter } from './middleware/rateLimiter.js';

// Route imports
import authRoutes         from './routes/authRoutes.js';
import doctorRoutes       from './routes/doctorRoutes.js';
import adminRoutes        from './routes/adminRoutes.js';
import receptionistRoutes from './routes/receptionistRoutes.js';
import patientRoutes      from './routes/patientRoutes.js';
import healthPackageRoutes from './routes/healthPackageRoutes.js';
import dashboardRoutes    from './routes/dashboardRoutes.js';

dotenv.config();

// ─── Database + Redis ─────────────────────────────────────────────────────────
connectDB();
getRedisClient(); // initialise connection on startup

const app = express();

// ─── Security headers (helmet) ────────────────────────────────────────────────
app.use(helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
    contentSecurityPolicy: {
        directives: {
            defaultSrc:  ["'self'"],
            scriptSrc:   ["'self'"],
            styleSrc:    ["'self'", "'unsafe-inline'"],
            imgSrc:      ["'self'", 'data:', 'https:'],
            connectSrc:  ["'self'"],
            frameSrc:    ["'none'"],
            objectSrc:   ["'none'"],
            upgradeInsecureRequests: [],
        },
    },
}));

// ─── CORS ─────────────────────────────────────────────────────────────────────
const allowedOrigins = (process.env.CLIENT_ORIGIN || 'http://localhost:3000')
    .split(',')
    .map((o) => o.trim());

app.use(cors({
    origin(origin, callback) {
        // Allow requests with no origin (curl, Postman, mobile apps)
        if (!origin) return callback(null, true);
        if (allowedOrigins.includes(origin)) return callback(null, true);
        callback(new Error(`CORS: origin ${origin} not allowed`));
    },
    credentials:        true,  // required for cookies
    optionsSuccessStatus: 200,
}));

// ─── Body + cookie parsers ────────────────────────────────────────────────────
app.use(express.json({ limit: '10kb' }));   // limit body size to prevent large payload attacks
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(cookieParser());

// Trust first proxy (Render, Heroku, Railway all sit behind one)
app.set('trust proxy', 1);

// ─── Global rate limiter ──────────────────────────────────────────────────────
app.use('/api', apiRateLimiter);

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use('/api/auth',         authRoutes);
app.use('/api/doctors',      doctorRoutes);
app.use('/api/admin',        adminRoutes);
app.use('/api/receptionist', receptionistRoutes);
app.use('/api/patient',      patientRoutes);
app.use('/api/packages',     healthPackageRoutes);
app.use('/api/dashboard',    dashboardRoutes);

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', ts: Date.now() }));

// ─── 404 handler ──────────────────────────────────────────────────────────────
app.use((_req, res) => res.status(404).json({ message: 'Route not found' }));

// ─── Global error handler ─────────────────────────────────────────────────────
// Catches any error passed to next(err) or unhandled promise rejections
// (Express 5 auto-catches async errors).
// IMPORTANT: never send stack traces to the client in production.
app.use((err, _req, res, _next) => {
    console.error('[Server] unhandled error:', err);
    const status  = err.status || err.statusCode || 500;
    const message = process.env.NODE_ENV === 'production'
        ? 'An unexpected error occurred'
        : err.message;
    res.status(status).json({ message });
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`[Server] running on port ${PORT} (${process.env.NODE_ENV || 'development'})`));
