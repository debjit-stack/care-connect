# Phase 1 — Auth Overhaul: Package Installation

## Server
```bash
cd server
npm install zod express-rate-limit ioredis cookie-parser helmet cors
npm install --save-dev @types/cookie-parser
```

## Client
```bash
cd client
npm install axios
# axios is already installed — no new client deps needed for auth
```

## Required ENV additions (server/.env)
```env
# Existing
MONGO_URI=your_mongodb_uri
JWT_SECRET=your_jwt_secret
PORT=5000

# NEW — add these
JWT_ACCESS_EXPIRES=15m
JWT_REFRESH_SECRET=a_different_long_random_secret_for_refresh_tokens
JWT_REFRESH_EXPIRES=7d
REDIS_URL=redis://localhost:6379
NODE_ENV=development
CLIENT_ORIGIN=http://localhost:3000
```
